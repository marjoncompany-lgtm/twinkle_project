import test from 'node:test';
import assert from 'node:assert/strict';
import { makeSafeFilename, buildSrt, createWavBuffer } from '../src/production.js';

test('makeSafeFilename removes path traversal and unsupported characters', () => {
  assert.equal(makeSafeFilename('../../my song: final?.wav'), 'my-song-final.wav');
});

test('buildSrt emits numbered timestamped captions', () => {
  assert.equal(buildSrt(['Hello world', 'Second line'], 2),
    '1\n00:00:00,000 --> 00:00:01,000\nHello world\n\n2\n00:00:01,000 --> 00:00:02,000\nSecond line');
});

test('createWavBuffer returns a valid PCM WAV header', () => {
  const bytes = createWavBuffer({ durationSeconds: 1, sampleRate: 8000, frequency: 440 });
  assert.equal(bytes.toString('ascii', 0, 4), 'RIFF');
  assert.equal(bytes.toString('ascii', 8, 12), 'WAVE');
  assert.equal(bytes.readUInt32LE(24), 8000);
  assert.equal(bytes.readUInt32LE(40), 16000);
  assert.equal(bytes.length, 44 + 16000);
});
